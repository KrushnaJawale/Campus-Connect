from flask import Flask, render_template, request, redirect, url_for, session, flash
import re
from data.manage_trip import manage_trip
from auth.auth import login, register, logout, login_check
from dashboard.dashboard import dashboard
from profile.profile import update_profile
from conn import create_database, dummy_feed

create_database()


app = Flask(__name__, template_folder='templetes')
secret_key = 'your_secret_key'
app.secret_key = 'your_secret_key'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['POST', 'GET'])
def login_route():
    return login()

@app.route('/register', methods=['POST', 'GET'])
def register_route():
    return register()

@app.route('/logout')
def logout_route():
    return logout()

@app.route('/dashboard')
def dashboard_route():
    if not login_check():
        return redirect(url_for('login_route'))
    return dashboard()

@app.route('/manage_trip', methods=['POST', 'GET'])
def manage_trip_route():
    if not login_check():
        return redirect(url_for('login_route'))
    return manage_trip()

@app.route('/profile', methods=['POST', 'GET'])
def profile_route():
    if not login_check():
        return redirect(url_for('login_route'))
    return update_profile()

if __name__ == '__main__':
    app.run(debug=True)