import sqlite3

# 连接到 SQLite 数据库 'database.db'
# 如果数据库文件不存在，此命令将会创建一个新的
conn = sqlite3.connect('database.db')

# 检查数据库连接是否成功建立
if conn:
    # 打印连接成功的消息
    print("Database connected successfully.")
    # 创建一个游标对象，用于执行 SQL 语句
    cursor = conn.cursor()
    
    # 执行 SQL 查询，从 'users' 表中选择所有记录
    cursor.execute('''
    SELECT * FROM users
    ''')
    # 获取查询结果集中的所有行
    users = cursor.fetchall()
    # 打印获取到的用户数据
    print(users)
    print("Users fetched successfully.")
    
    # 执行 SQL 查询，从 'trips' 表中选择所有记录
    cursor.execute('''
    SELECT * FROM trips
    ''')
    # 获取查询结果集中的所有行
    trips = cursor.fetchall()
    # 打印获取到的行程数据
    print(trips)
    print("Trips fetched successfully.")

    # 操作完成后关闭数据库连接
    conn.close()
    print("Database connection closed.")
else:
    print("Failed to connect to the database.")



