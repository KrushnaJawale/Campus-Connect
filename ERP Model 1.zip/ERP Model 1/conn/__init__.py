from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
import re   

def create_database():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    if conn:
        print("Database connected successfully.")   
        cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email_id TEXT NOT NULL UNIQUE,
        mobile TEXT NOT NULL UNIQUE,
        college TEXT NOT NULL,
        course TEXT NOT NULL,
        branch TEXT NOT NULL,
        year TEXT NOT NULL,
        password_hash TEXT NOT NULL
    )
    ''')
        cursor.execute('''
    CREATE TABLE IF NOT EXISTS trips (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email_id TEXT NOT NULL,
        college TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        start TEXT NOT NULL,
        end TEXT NOT NULL
    )
    ''')
        
    conn.commit()
    conn.close()



def dummy_feed():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    if conn:
        print("Database connected successfully.")
        cursor.execute('''
    INSERT INTO users (name, email_id, mobile, college, course, branch, year, password_hash) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', ('Dummy User', 'dummy@example.com', '1234567890', 'Dummy College', 'Dummy Course', 'Dummy Branch', 'Dummy Year', 'dummy123'))
        cursor.execute('''INSERT INTO users (name, email_id, mobile, college, course, branch, year, password_hash) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', ('Krushna', 'krushna@example.com', '0987654321', 'Dummy College', 'Dummy Course', 'Dummy Branch', 'Dummy Year', 'krushna123'))
        cursor.execute('''
    INSERT INTO trips (name, email_id, college, timestamp, start, end) VALUES (?, ?, ?, ?, ?, ?)
    ''', ('Dummy User', 'dummy@example.com', 'Dummy College', '2023-12-01 10:00:00', 'Start Point', 'End Point'))
        cursor.execute('''
    INSERT INTO trips (name, email_id, college, timestamp, start, end) VALUES (?, ?, ?, ?, ?, ?)
    ''', ('Krushna', 'krushna@example.com', 'Sit lonavala', '2023-12-02 14:30:00', 'Sit campus', 'Railway Station'))
        conn.commit()
        conn.close()
        return True
    else:
        print("Database connection failed.")
        return None



def connect_database(data_type):
    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        if conn:
            print("Database connected successfully.")
            if data_type == 'users':
                cursor.execute('''
    SELECT * FROM users
    ''')
                users = cursor.fetchall()
                print(users)
                print("Users fetched successfully.")
                return users
            elif data_type == 'trips':
                cursor.execute('''
    SELECT * FROM trips
    ''')
                trips = cursor.fetchall()
                return trips
            else:
                print("Invalid data type.")
                return None

        return cursor, conn
    except sqlite3.Error as e:
        print(f"Database connection failed: {e}")
        return None, None
    


    
def update_database(data_type, data):
    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        if conn:
            print("Database connected successfully.")
            if data_type == 'users':
                cursor.execute('''
    UPDATE users SET name=?, email_id=?, mobile=?, college=?, course=?, branch=?, year=?, password_hash=? WHERE id=?
    ''', (data['name'], data['email_id'], data['mobile'], data['college'], data['course'], data['branch'], data['year'], data['password_hash'], data['id']))
                conn.commit()
                conn.close()
                flash("User updated successfully!", 'success')
                return True
            elif data_type == 'trips':
                cursor.execute('''
    UPDATE trips SET name=?, email_id=?, college=?, timestamp=?, start=?, end=? WHERE id=?
    ''', (data['name'], data['email_id'], data['college'], data['timestamp'], data['start'], data['end'], data['id']))
                conn.commit()
                conn.close()
                flash("Trip updated successfully!", 'success')
                return True
            else:
                print("Invalid data type.")
                flash("Invalid data type.", 'error')
                return None
        else:
            print("Database connection failed.")
            flash("Database connection failed.", 'error')
            return None
        
    except sqlite3.Error as e:
        print(f"Database update failed: {e}")
        flash(f"Database update failed: {e}", 'error')
        return None
    



def remove_trip(data):
    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        if conn:
            print("Database connected successfully.")
            cursor.execute('''
    DELETE FROM trips WHERE id=?
    ''', (data['id'],))
            conn.commit()
            conn.close()
            flash("Trip deleted successfully!", 'success')
            return True
        else:
            print("Database connection failed.")
            return None
        
    except sqlite3.Error as e:
        print(f"Database update failed: {e}")
        return None
    
    


def all_user_data_from_database():
    all_user_data_from_database = connect_database('users')
    return all_user_data_from_database


def all_trip_data_from_database():
    all_trip_data_from_database = connect_database('trips')
    return all_trip_data_from_database

def user_data_from_database():
    all_user_data_from_database = connect_database('users')
    for user in all_user_data_from_database:
        if user[2] == session['user']:
            user_data_from_database = user
            return user_data_from_database 
    flash("User not found.", 'error')
    return redirect(url_for('login_route'))
        
def user_all_trip_data_from_database():
    all_trip_data_from_database = connect_database('trips')
    user_all_trip_data = []
    for trip in all_trip_data_from_database:
        if trip[2] == session['user']:
            user_all_trip_data.append(trip)
    if not user_all_trip_data:
        flash("Trip not found.", 'error')
        return redirect(url_for('login_route'))
    return user_all_trip_data
        
def all_trip_data_from_database():
    all_trip_data_from_database = connect_database('trips')
    return all_trip_data_from_database