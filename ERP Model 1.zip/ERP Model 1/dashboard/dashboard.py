from flask import Flask, render_template, request, redirect, url_for, session, flash
from conn import all_trip_data_from_database, user_data_from_database
from auth.auth import login_check
import re
def dashboard():
       login_check()
       all_trip_data = all_trip_data_from_database()
       all_trip_data = all_trip_data[::-1]

       all_trip_data = [
              {
                     "id": trip[0],
                     "name": trip[1],
                     "email_id": trip[2],
                     "college": trip[3],
                     "timestamp": trip[4],
                     "start": trip[5],
                     "end": trip[6]
              }
              for trip in all_trip_data
       ]

       name = user_data_from_database()['name']
       return render_template('dashboard.html', name=name, all_trip_data = all_trip_data)