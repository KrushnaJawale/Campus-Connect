from flask import render_template, request, redirect, url_for, flash, session
from conn import all_trip_data_from_database, update_database, remove_trip, user_data_from_database
import re



def manage_trip():
    all_trip_data = all_trip_data_from_database()
    name = user_data_from_database()[1]
    if request.method == 'POST':
        data = request.form
        switch = data.get('switch')

        if switch == 'add':
            # Validate fields
            required_fields = ['switch','college', 'date', 'time', 'start', 'end']
            if not all(data.get(field) for field in required_fields):
                flash("All fields are required.", 'error')
                return redirect(url_for('manage_trip_route'))

            # Create and add trip
            trip_id = max(trip["id"] for trip in all_trip_data) + 1
            trip = {
                "id": trip_id,
                "name": name,
                "email_id": session.get('user'),
                "college": data.get('college'),
                "timestamp": f"{data.get('date')}T{data.get('time')}",
                "start": data.get('start'),
                "end": data.get('end')
            }
            all_trip_data.append(trip)
            update_database("trips", trip)
            flash("Trip successfully created!", 'success')
            return redirect(url_for('manage_trip_route'))
        

        elif switch == 'remove':
            trip_id = data.get('trip_id')
            if not trip_id:
                flash("Trip ID is required.", 'error')
                return redirect(url_for('manage_trip_route'))
            
            # Use a safer way to find and remove the trip
            trip_to_remove = None
            for trip in all_trip_data:
                if trip.get("id") == int(trip_id) and trip.get("email_id") == session.get("user"):
                    trip_to_remove = trip
                    break
            
            if trip_to_remove:
                all_trip_data.remove(trip_to_remove)
                remove_trip(trip_to_remove)
                flash("Trip successfully removed!", 'success')
            else:
                flash("Invalid trip ID or permission denied.", 'error')
            return redirect(url_for('manage_trip_route'))

    # GET request: Show form with user's trips
    # Filter trips for the current user and sort them with the newest first.
    all_trip_data_final=all_trip_data[::-1]
    return render_template('manage_trip.html', all_trip_data=all_trip_data_final)
