from flask import render_template, request, redirect, url_for, session, flash
from conn import all_user_data_from_database, user_data_from_database, update_database
import sqlite3
import re


def login_check():
    season_email_id = session.get('user')
    season_password = session.get('password')
    if not season_email_id or not season_password:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        
        cursor.execute(
            '''
            SELECT * FROM users WHERE email_id = ? AND password_hash = ?
            ''', 
            (session['user'], session['password'])
        )
        user = cursor.fetchone()
        conn.close()

        if not user or not user[2]==season_email_id or not user[8]==season_password :
            session.pop('user', None)
            session.pop('password', None)
            flash("Your session is invalid. Please log in again.", 'error')
            return redirect(url_for('login_route'))
    return redirect(url_for('login_route'))

    
        
    
        
def login():
    if request.method == 'POST':
        data = request.form
        posted_email_id = data.get('email_id')
        posted_password = data.get('password')
        all_users = all_user_data_from_database()
        if posted_email_id and posted_password:
            for user in all_users:
                if user[2] == posted_email_id:
                    
                    if user[8] == posted_password:
                        session['user'] = posted_email_id
                        session['password'] = posted_password
                        flash("Login successful!", 'success')
                        return redirect(url_for('dashboard_route'))
                    else:
                        flash("Invalid credentials.", 'error')
                        print(all_users)
                        return redirect(url_for('login_route'))
            flash("Invalid credentials.", 'error')
            return redirect(url_for('login_route'))
        else:
            flash("Email ID and Password are required.", 'error')
            return redirect(url_for('login_route'))
            
    return render_template('login.html')


def register():
    if request.method == 'POST':
        data = request.form
        user_data = {}
        all_users = all_user_data_from_database()
        max_id = 0
        for user in all_users:
            if user[0] > max_id:
                max_id = user[0]
        user_data['id'] = max_id + 1
            


        
        full_name = data.get('full_name')
        if not full_name or len(full_name) < 3:
            flash("Full Name required (min 3 chars).", 'error')
            return redirect(url_for('register_route'))
        user_data['name'] = full_name
        
        email_id = data.get('email_id')
        if not re.match(r'[^@]+@[^@]+\.[^@]+', email_id):
            flash("Invalid email format.", 'error')
            return redirect(url_for('register_route'))
        user_data['email_id'] = email_id
        
        phone = data.get('phone')
        if not (phone and phone.isdigit() and len(phone) == 10):
            flash("Mobile number must be 10 digits.", 'error')
            return redirect(url_for('register_route'))
        user_data['mobile'] = phone

        password = data.get('password')
        if len(password) < 8:
            flash("Password must be a minimum of 8 characters.", 'error')
            return redirect(url_for('register_route'))
        
        user_data['password_hash'] = password
        user_data['college'] = data.get('college')
        user_data['course'] = data.get('course')
        user_data['branch'] = data.get('branch')
        user_data['year'] = data.get('year')
        user_data['terms_agreed'] = data.get('terms')
        print(user_data) 
        flash("Account successfully created!", 'success')
        session['user'] = email_id
        session['password'] = password
        update_database("users", user_data)
        return redirect(url_for('login_route'))
    return render_template('register.html')



def logout():
    session.pop('user', None)
    session.pop('password', None)
    flash("You have been logged out.", 'success')
    return redirect(url_for('login_route'))