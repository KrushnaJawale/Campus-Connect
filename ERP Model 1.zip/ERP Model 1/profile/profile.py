from flask import Flask, render_template, request, redirect, url_for, session, flash
from conn import user_data_from_database, update_database
import re

def update_profile():
    user_data = user_data_from_database()
    #user_data = {"id":1 , "name":"Krushna Jawale","email_id":"admin@example.com","mobile":"9876543210","college":"SIT Lonavala","course":"Computer Science","branch":"Information Technology","year":"2nd Year"}
    if request.method == 'POST':
        data = request.form
        user_data = {}
        
        full_name = data.get('full_name')
        if not full_name or len(full_name.strip()) < 3:
            flash("Full Name required (min 3 chars).", 'error')
            return redirect(url_for('profile_route'))
        user_data['full_name'] = full_name
        
        phone = data.get('phone')
        if not (phone and phone.isdigit() and len(phone) == 10):
            flash("Mobile number must be 10 digits.", 'error')
            return redirect(url_for('profile_route'))
        user_data['phone'] = phone

        password = data.get('password')
        if len(password) < 8:
            flash("Password must be a minimum of 8 characters.", 'error')
            return redirect(url_for('profile_route'))
        
        user_data['password_hash'] = f"HASHED_{password[:4]}" 
        user_data['college'] = data.get('college')
        user_data['course'] = data.get('course')
        user_data['branch'] = data.get('branch')
        user_data['year'] = data.get('year')
        user_data['terms_agreed'] = data.get('terms')
        print(user_data) 
        update_database("users", user_data)
        flash("Account successfully updated!", 'success')
        return redirect(url_for('profile_route'))
    return render_template('profile.html', user=user_data)
